/*
Name: Sabir Husnain
Roll No. 2019 MC 263
Section: A
*/

#include <iostream>
#include <fstream>
#include <conio.h>

using namespace std;

/*
A simple code to get familiar with "exit(1)" and "break" in c++.
if one enter a positive enterger it will be added in the sum and sum 
will be stored.
But if some enters -1 code will break and sum will be displayed.
And if -2 is entered program will exit and nothing displays.
*/

int main()
{
     cout << "Program for Difference between \'exit(1)\' and \'break\' in c++" << endl;
     int num, sum = 0;
     cout << "---> Enter a positive number," << endl
          << "---> Break: -1" << endl
          << "---> Exit: -2" << endl;
     while (true)
     {
          cout << "Your Choice: ";
          cin >> num;
          if (num > 0)
          {
               sum = sum + num;
          }
          else if (num == -1)
          {
               break;
          }
          else if (num == -2)
          {
               cout << "Exiting..." << endl;
               exit(1);
          }
          else
          {
               cout << "Wrong Choice" << endl;
          }
     }
     cout << "Sum is: " << sum << endl;
     getch();
     return 0;
}