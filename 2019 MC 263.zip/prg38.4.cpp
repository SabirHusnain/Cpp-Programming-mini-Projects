/*
Name: Sabir Husnain
Roll No. 2019 MC 263
Section: A
*/

/*
I have a text file named UET.txt and contains information of a student:-

Name: Sabir Husnain
Roll No. 2019-MC-263
Department: Mechatronics
CGPA: 3.72

Now I will read that data and write it to other file named Engineering.txt
*/
#include <iostream>
#include <fstream>
#include <conio.h>

using namespace std;

int main()
{

     char temp[100]; // temp will store all the lines present in file
     ifstream in("UET.txt");
     ofstream out("Engineering.txt");
     if (!in)
     {
          cout << "File Opening Error for file from which data is being copied" << endl;
          exit(0);
     }
     if (!out)
     {
          cout << "File Opening Error for file in which data is being copied" << endl;
          exit(0);
     }
     while (in.eof() == 0)
     {
          in.getline(temp, 100);
          out << temp << endl;
     }
     in.close();
     out.close();
     cout << "Data has successfully been saved" << endl;
     getch();
     return 0;
}