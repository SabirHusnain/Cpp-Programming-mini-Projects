#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
     int i = 1;
     while (i <= 10)
     {
          cout << i << endl;
          i=i+2;
     }
     getch();
     return 0;
}