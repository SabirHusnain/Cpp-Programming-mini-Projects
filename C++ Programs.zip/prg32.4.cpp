#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
     int a;
     cout<<"Enter a number: ";
     cin>>a;
     if (a==1)
     {
          cout<<1<<endl;
     }
     else if (a==2)
     {
          cout<<2<<endl;
     }
     else if (a==3)
     {
          cout<<3<<endl;
     }
     else if (a==4)
     {
          cout<<4<<endl;
     }
     else
     {
          cout<<"Any other Number: ";
     }
     
     getch();
     return 0;
}
