#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
     for (int i = 1; i <= 10; i=i*2)
     {
          cout << i << endl;
     }

     getch();
     return 0;
}