#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
     for (int i = 100; i >= 1; i=i/2)
     {
          cout << i << endl;
     }

     getch();
     return 0;
}