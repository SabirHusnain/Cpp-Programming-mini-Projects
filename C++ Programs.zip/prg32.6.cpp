#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
     for (int i = 12; i >= 1; i--)
     {
          cout << i << endl;
     }

     getch();
     return 0;
}