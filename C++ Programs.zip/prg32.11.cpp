#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
     int i = 10;
     while (i >= 1)
     {
          cout << i << endl;
          i--;
     }
     getch();
     return 0;
}